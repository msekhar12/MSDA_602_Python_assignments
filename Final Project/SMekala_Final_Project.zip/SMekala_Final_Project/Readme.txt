Hello Andrew,

I am submitting all the project document in the form of an IPython notebook. I am also providing the data set named: Infectious_Disease.csv. If you want to execute the code segments in the ipython notebook, please start from the first section. For easy navigation within the notebook, I provided an index. In the third section of the document (see the index in the ipython notebook), you will be prompted to enter the location of the file. Please paste the directory where the file name Infectious_Disease.csv is downloaded. The code will load the file into a pandas data frame.

In the project initial draft (part 1 and part 2) I have written that I will be doing Monte Carlo Simulation to predict the possible percentage of disease spread in next 3 years. But I gave up that idea, since I found PCA (Principal Component Analysis) more appropriate to this data set. I found some data anamolies in PCA method. 

Please let me know if you have any questions. 

Thanks in advance,
Sekhar Mekala